--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE hotel_db;
--
-- Name: hotel_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE hotel_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE hotel_db OWNER TO postgres;

\unrestrict (null)
\connect hotel_db
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: amenity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.amenity (
    amenityid integer NOT NULL,
    amenityname character varying(50) NOT NULL,
    amenitycategory character varying(50)
);


ALTER TABLE public.amenity OWNER TO postgres;

--
-- Name: pricerate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pricerate (
    rateid integer NOT NULL,
    seasonid integer NOT NULL,
    offerid integer,
    roomtypeid integer NOT NULL,
    finalprice numeric(10,2) NOT NULL,
    CONSTRAINT pricerate_finalprice_check CHECK ((finalprice > (0)::numeric))
);


ALTER TABLE public.pricerate OWNER TO postgres;

--
-- Name: room; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room (
    roomid integer NOT NULL,
    roomnumber integer NOT NULL,
    floor integer NOT NULL,
    maxoccupancy integer NOT NULL,
    phonenumber character varying(20),
    roomtypeid integer NOT NULL,
    statusid integer NOT NULL,
    CONSTRAINT chk_valid_occupancy CHECK ((maxoccupancy > 0)),
    CONSTRAINT room_floor_check CHECK ((floor >= '-1'::integer)),
    CONSTRAINT room_maxoccupancy_check CHECK ((maxoccupancy > 0))
);


ALTER TABLE public.room OWNER TO postgres;

--
-- Name: roomamenity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roomamenity (
    roomid integer NOT NULL,
    amenityid integer NOT NULL
);


ALTER TABLE public.roomamenity OWNER TO postgres;

--
-- Name: roommaintenance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roommaintenance (
    maintenanceid integer NOT NULL,
    startdate date NOT NULL,
    enddate date,
    description character varying(1000) NOT NULL,
    repaircost numeric(10,2) DEFAULT 0,
    maintenancestatus character varying(20) NOT NULL,
    roomid integer NOT NULL,
    CONSTRAINT chk_maint_dates CHECK (((enddate >= startdate) OR (enddate IS NULL))),
    CONSTRAINT chk_maint_status CHECK (((maintenancestatus)::text = ANY ((ARRAY['Reported'::character varying, 'In Progress'::character varying, 'Fixed'::character varying, 'Verified'::character varying])::text[]))),
    CONSTRAINT roommaintenance_repaircost_check CHECK ((repaircost >= (0)::numeric))
);


ALTER TABLE public.roommaintenance OWNER TO postgres;

--
-- Name: roomstatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roomstatus (
    statusid integer NOT NULL,
    statusname character varying(20) NOT NULL
);


ALTER TABLE public.roomstatus OWNER TO postgres;

--
-- Name: roomtype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roomtype (
    roomtypeid integer NOT NULL,
    typename character varying(50) NOT NULL,
    baseprice numeric(10,2) NOT NULL,
    description character varying(500),
    bedtype character varying(50),
    CONSTRAINT chk_positive_base_price CHECK ((baseprice > (0)::numeric)),
    CONSTRAINT roomtype_baseprice_check CHECK ((baseprice > (0)::numeric))
);


ALTER TABLE public.roomtype OWNER TO postgres;

--
-- Name: season; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.season (
    seasonid integer NOT NULL,
    seasonname character varying(50) NOT NULL,
    startdate date NOT NULL,
    enddate date NOT NULL,
    CONSTRAINT chk_season_dates CHECK ((enddate > startdate))
);


ALTER TABLE public.season OWNER TO postgres;

--
-- Name: specialoffer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.specialoffer (
    offerid integer NOT NULL,
    offername character varying(50) NOT NULL,
    discountpercentage numeric(5,2) DEFAULT 0,
    CONSTRAINT chk_valid_discount CHECK (((discountpercentage >= (0)::numeric) AND (discountpercentage <= (100)::numeric))),
    CONSTRAINT specialoffer_discountpercentage_check CHECK (((discountpercentage >= (0)::numeric) AND (discountpercentage <= (100)::numeric)))
);


ALTER TABLE public.specialoffer OWNER TO postgres;

--
-- Data for Name: amenity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.amenity (amenityid, amenityname, amenitycategory) FROM stdin;
\.
COPY public.amenity (amenityid, amenityname, amenitycategory) FROM '$$PATH$$/3517.dat';

--
-- Data for Name: pricerate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pricerate (rateid, seasonid, offerid, roomtypeid, finalprice) FROM stdin;
\.
COPY public.pricerate (rateid, seasonid, offerid, roomtypeid, finalprice) FROM '$$PATH$$/3521.dat';

--
-- Data for Name: room; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.room (roomid, roomnumber, floor, maxoccupancy, phonenumber, roomtypeid, statusid) FROM stdin;
\.
COPY public.room (roomid, roomnumber, floor, maxoccupancy, phonenumber, roomtypeid, statusid) FROM '$$PATH$$/3516.dat';

--
-- Data for Name: roomamenity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roomamenity (roomid, amenityid) FROM stdin;
\.
COPY public.roomamenity (roomid, amenityid) FROM '$$PATH$$/3522.dat';

--
-- Data for Name: roommaintenance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roommaintenance (maintenanceid, startdate, enddate, description, repaircost, maintenancestatus, roomid) FROM stdin;
\.
COPY public.roommaintenance (maintenanceid, startdate, enddate, description, repaircost, maintenancestatus, roomid) FROM '$$PATH$$/3518.dat';

--
-- Data for Name: roomstatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roomstatus (statusid, statusname) FROM stdin;
\.
COPY public.roomstatus (statusid, statusname) FROM '$$PATH$$/3515.dat';

--
-- Data for Name: roomtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roomtype (roomtypeid, typename, baseprice, description, bedtype) FROM stdin;
\.
COPY public.roomtype (roomtypeid, typename, baseprice, description, bedtype) FROM '$$PATH$$/3514.dat';

--
-- Data for Name: season; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.season (seasonid, seasonname, startdate, enddate) FROM stdin;
\.
COPY public.season (seasonid, seasonname, startdate, enddate) FROM '$$PATH$$/3519.dat';

--
-- Data for Name: specialoffer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.specialoffer (offerid, offername, discountpercentage) FROM stdin;
\.
COPY public.specialoffer (offerid, offername, discountpercentage) FROM '$$PATH$$/3520.dat';

--
-- Name: amenity amenity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.amenity
    ADD CONSTRAINT amenity_pkey PRIMARY KEY (amenityid);


--
-- Name: pricerate pricerate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pricerate
    ADD CONSTRAINT pricerate_pkey PRIMARY KEY (rateid);


--
-- Name: room room_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_pkey PRIMARY KEY (roomid);


--
-- Name: room room_roomnumber_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_roomnumber_key UNIQUE (roomnumber);


--
-- Name: roomamenity roomamenity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roomamenity
    ADD CONSTRAINT roomamenity_pkey PRIMARY KEY (roomid, amenityid);


--
-- Name: roommaintenance roommaintenance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roommaintenance
    ADD CONSTRAINT roommaintenance_pkey PRIMARY KEY (maintenanceid);


--
-- Name: roomstatus roomstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roomstatus
    ADD CONSTRAINT roomstatus_pkey PRIMARY KEY (statusid);


--
-- Name: roomstatus roomstatus_statusname_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roomstatus
    ADD CONSTRAINT roomstatus_statusname_key UNIQUE (statusname);


--
-- Name: roomtype roomtype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roomtype
    ADD CONSTRAINT roomtype_pkey PRIMARY KEY (roomtypeid);


--
-- Name: season season_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.season
    ADD CONSTRAINT season_pkey PRIMARY KEY (seasonid);


--
-- Name: specialoffer specialoffer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specialoffer
    ADD CONSTRAINT specialoffer_pkey PRIMARY KEY (offerid);


--
-- Name: idx_maintenance_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_maintenance_status ON public.roommaintenance USING btree (maintenancestatus);


--
-- Name: idx_price_season; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_price_season ON public.pricerate USING btree (seasonid);


--
-- Name: idx_room_floor; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_room_floor ON public.room USING btree (floor);


--
-- Name: roommaintenance fk_maint_room; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roommaintenance
    ADD CONSTRAINT fk_maint_room FOREIGN KEY (roomid) REFERENCES public.room(roomid);


--
-- Name: pricerate fk_pr_offer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pricerate
    ADD CONSTRAINT fk_pr_offer FOREIGN KEY (offerid) REFERENCES public.specialoffer(offerid);


--
-- Name: pricerate fk_pr_roomtype; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pricerate
    ADD CONSTRAINT fk_pr_roomtype FOREIGN KEY (roomtypeid) REFERENCES public.roomtype(roomtypeid);


--
-- Name: pricerate fk_pr_season; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pricerate
    ADD CONSTRAINT fk_pr_season FOREIGN KEY (seasonid) REFERENCES public.season(seasonid);


--
-- Name: roomamenity fk_ra_amenity; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roomamenity
    ADD CONSTRAINT fk_ra_amenity FOREIGN KEY (amenityid) REFERENCES public.amenity(amenityid);


--
-- Name: roomamenity fk_ra_room; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roomamenity
    ADD CONSTRAINT fk_ra_room FOREIGN KEY (roomid) REFERENCES public.room(roomid);


--
-- Name: room fk_room_status; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT fk_room_status FOREIGN KEY (statusid) REFERENCES public.roomstatus(statusid);


--
-- Name: room fk_room_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT fk_room_type FOREIGN KEY (roomtypeid) REFERENCES public.roomtype(roomtypeid);


--
-- PostgreSQL database dump complete
--

